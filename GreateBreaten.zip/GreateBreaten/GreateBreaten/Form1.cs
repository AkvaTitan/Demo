﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace GreateBreaten
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.Product". При необходимости она может быть перемещена или удалена.
            this.productTableAdapter.Fill(this.dataSet1.Product);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                dataGridView1.Rows[i].Selected = false;
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                    if (dataGridView1.Rows[i].Cells[j].Value != null)
                        if (dataGridView1.Rows[i].Cells[j].Value.ToString().Contains(textBox1.Text))
                        {
                            dataGridView1.Rows[i].Selected = true;
                            break;
                        }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Deletebutton_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.SelectedRows)
            {
                    dataGridView1.Rows.Remove(row); 
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            productTableAdapter.Update(dataSet1);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 f = new Form3();
            f.Show();
        }

        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
                var x = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
                pictureBox3.ImageLocation = x;
                Console.WriteLine(x);
                var y = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                label4.Text = y;
                var a = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                label5.Text = a;
                var b = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                label6.Text = b;

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
